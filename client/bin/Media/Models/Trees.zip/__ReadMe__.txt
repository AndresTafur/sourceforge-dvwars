//////////////////////////////////////////////////////////
// "Veggies for the people"				//
// (c) 3D-Diggers 2008					//
// Author: Christian Herzog				//
// Web: www.3d-diggers.de				//
//////////////////////////////////////////////////////////

+--------------------------------------------------------+
| License: 						 |
+--------------------------------------------------------+
"Do what you want"

This is a free give away from the 3D-Diggers.
You can use it in any project you want (commercial, non-commercial, etc.).


I'd be happy though, if anybody using it, could send me a link to the project or so! (just to know IF this is actually being used... ;) )
But again, you don't have to.
My email is Giggsy@gmx.at.

If you want to see more, drop by on our homepage: www.3d-diggers.de.
(you get the full fir pack there, which can easily be exported for OGRE as you can see)